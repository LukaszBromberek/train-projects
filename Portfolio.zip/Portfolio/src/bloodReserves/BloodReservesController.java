package bloodReserves;

import java.lang.StringBuilder;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.URL;
import java.security.cert.Certificate;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;
import java.time.ZoneId;
import java.time.ZonedDateTime;

import javax.annotation.Resource;
import javax.net.ssl.HttpsURLConnection;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import bloodReserves.model.BloodReservesModel;

/**
 * Servlet implementation class BloodReservesController
 */
@WebServlet("/BloodReservesController")
public class BloodReservesController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final int ACTUALISATION_INTERVAL = 12;
	ScheduledExecutorService actualizationChecker;
	@Resource(name = "jdbc/project")			//Server on mamp
	DataSource dataSource;
//	@Resource(name = "jdbc/serwer1910176db")	//Web test server
	/*
	 * DataSource dataSource = new DataSource() {
	 * 
	 * @Override public <T> T unwrap(Class<T> iface) throws SQLException { // TODO
	 * Auto-generated method stub return null; }
	 * 
	 * @Override public boolean isWrapperFor(Class<?> iface) throws SQLException {
	 * // TODO Auto-generated method stub return false; }
	 * 
	 * @Override public void setLoginTimeout(int seconds) throws SQLException { //
	 * TODO Auto-generated method stub
	 * 
	 * }
	 * 
	 * @Override public void setLogWriter(PrintWriter out) throws SQLException { //
	 * TODO Auto-generated method stub
	 * 
	 * }
	 * 
	 * @Override public Logger getParentLogger() throws
	 * SQLFeatureNotSupportedException { // TODO Auto-generated method stub return
	 * null; }
	 * 
	 * @Override public int getLoginTimeout() throws SQLException { // TODO
	 * Auto-generated method stub return 0; }
	 * 
	 * @Override public PrintWriter getLogWriter() throws SQLException { // TODO
	 * Auto-generated method stub return null; }
	 * 
	 * @Override public Connection getConnection(String username, String password)
	 * throws SQLException { // TODO Auto-generated method stub return null; }
	 * 
	 * @Override public Connection getConnection() throws SQLException { Proxy proxy
	 * = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("10.252.76.110",8080 ));
	 * return
	 * DriverManager.getConnection("jdbc:mysql://serwer1910176.home.pl/sql:3306/",
	 * "31817028_blood_reserves", "hsGf1-#@rd4H"); } };
	 */
	
    public BloodReservesController() {
        super();
    }

    //Runs actualization process
	public void init(ServletConfig config) throws ServletException {
		// Set timer for checking if new blood level is available
		actualizationChecker = Executors.newScheduledThreadPool(1);		
		final Runnable actualizeBloodReserves = new Runnable() {
			
			@Override
			public void run() {
				System.out.println("Inicjalizuję sprawdzenie poziomu krwi");
				
				BloodReservesModel bloodModel = new BloodReservesModel(dataSource);
				String html = getHtml();
				
				//Will insert data to database, if data is new
				bloodModel.tryToActualize(html);
			}
		};
		
		actualizationChecker.scheduleAtFixedRate(actualizeBloodReserves, 0, ACTUALISATION_INTERVAL, TimeUnit.HOURS);	
	}

	//Terminate scheduled task
	@Override
	public void destroy() {
		actualizationChecker.shutdownNow();
		Executors.newScheduledThreadPool(0);
		super.destroy();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		String page=request.getParameter("page").toLowerCase();
		
		switch(page) {
		case "gethtml":
			request.setAttribute("html", getHtml());
			request.getRequestDispatcher("bloodHTML.jsp").forward(request, response);
			break;
		default: 
			request.getRequestDispatcher("blood.jsp").forward(request, response);
		}
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	public String getHtml() {
		String sURL = "https://krew.info/zapasy/";
		System.out.println("Trying to get URL : " + sURL);
		
		
		URL url=null;
		HttpsURLConnection httpCon;		
		Proxy proxy=null;
		
		//Parse URL to URL object
		try {
			
			// @Kaczka - ta linia kodu ulegnie zmianie przy przeniesieniu na właściwy serwer. Ustawienia proxy były wymagane do przejścia
			// przez proxy firmowe
			proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("10.252.76.110",8080 ));
			// ---------------------------------------------------------------------------------
			
			url = new URL(sURL);

		} catch (MalformedURLException e) {
			System.out.println("Error : Getting URL unsuccessful!");
			e.printStackTrace();
		}
		
		// Try to connect with website and parse HTML code to String
		try {
			
			httpCon = (HttpsURLConnection) url.openConnection(proxy);
			
			BufferedReader in = new BufferedReader(new InputStreamReader(httpCon.getInputStream()));
			String inputLine;
			StringBuilder builder = new StringBuilder();
			
			while((inputLine = in.readLine())!= null) {
				
				builder.append(inputLine);
			}
			in.close();
			
			httpCon.disconnect();
			
			
			
//			String ret_val = builder.toString().replaceAll("\"", "'");
//			return ret_val;
			return builder.toString();
		} catch (IOException e) {
			System.out.println("Error : Connecting with webpage unsuccessful!");
			e.printStackTrace();
		}
		
		return null;
	}

}
