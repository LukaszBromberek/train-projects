package bloodReserves.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.sql.DataSource;

import bloodReserves.enums.BloodType;
import bloodReserves.process.BloodDataProcessor;
import bloodReserves.process.CitiesList;
import bloodReserves.process.ProcessedBloodData;
import bloodReserves.process.TableRow;

public class BloodReservesModel {
	private ProcessedBloodData data;
	private DataSource dataSource;
	private BloodDataProcessor processor;
	public Tester tester;
	
	public class Tester{
		public boolean testIsDateInBase(GregorianCalendar date) {
			boolean result = isDateInBase(date);
			System.out.println("IsDateInBase result : " + result);
			return result;
		}
	}
	
	public BloodReservesModel(DataSource dataSource) {
		
		
		this.dataSource = dataSource;
		this.tester=new Tester();
		
	}

//Main function called by servlet timer
	public void tryToActualize(String html) {
System.out.println("Debug: inside tryToActualize");

System.out.println("Debug: init BloodDataProcessor");
		this.processor = new BloodDataProcessor (html);
		this.data = new ProcessedBloodData();
		
System.out.println("Debug: getActualizationDate");
		this.data.setActualizationDate(processor.getDate());
		
		//Connect with DB
		if(this.isDateInBase(data.getActualizationDate())==false)
		{			
			
			  System.out.println("Debug: Inside isDateInBase");
			  this.processor.extractTable();
			  
			  System.out.println("Debug: calling insertDate"); //Send date to DB
			  this.insertDate();
			  
			  System.out.println("Debug: calling data.setCityNames"); //Extract cities
			  this.data.setCityNames(processor.extractCityName());
			  
			  System.out.println("Debug: calling data.setValueRows"); //Extract bloodLevels
			  this.data.setValuesRows(processor.extractBloodLevels());
			  
			  System.out.println("Debug: calling areAllCitiesInDBAndAddIfNotThenAdd");
			  //Check cities list, add some to DB if that's needed
			  this.areAllCitiesInDBAndAddIfNotThenAdd();
			  
			  System.out.println("Debug: caaling insertBloodLevels"); //Add blood levels
			  this.insertBloodLevels();
			 
		}


		
		
		
	}
	
	
	//Insert date to DB
	private void insertDate() {
System.out.println("Debug: GregorianCalendar date = this.data.getActualizationDate");
		GregorianCalendar date = this.data.getActualizationDate();
		
System.out.println("Debug: Print date to string");
		String dateString = date.get(Calendar.YEAR)+"-"
							+(date.get(Calendar.MONTH)+1)+"-"  //Bugfix: set january as 1, december as 12
							+date.get(Calendar.DAY_OF_MONTH)+" " 
							+date.get(Calendar.HOUR_OF_DAY)+":"
							+date.get(Calendar.MINUTE)+":00";
System.out.println("Debug: month : " + date.get(Calendar.MONTH));
System.out.println("Debug: dateString = " +dateString);		
		try {
System.out.println("Debug: inside try block");
System.out.println("Debug: create query");
			String query = "INSERT INTO `actualization_date`(`date`) VALUES (?)";
System.out.println("Debug: getConnection");
			Connection connection = this.dataSource.getConnection();
System.out.println("Debug: prepareStatement");
			PreparedStatement statement = connection.prepareStatement(query);
System.out.println("Debug: setString");
			statement.setString(1, dateString);
System.out.println("Debug: execute");
			statement.execute();
System.out.println("Debug: execute completed");
		} catch (SQLException e) {
System.out.println("Debug: inside catch block");
			e.printStackTrace();
		}
System.out.println("Debug: Outside try/catch block");
		
	}
	
	//This function connects with database and check if given date is already in base
	private boolean isDateInBase(GregorianCalendar date) {
		Connection connect=null;
		Statement stmt = null;
		ResultSet rs = null;
		
		//SELECT * FROM `test1` WHERE test_date = '2018-4-3 2:14:00' 
		
		String query="Select * from actualization_date where date = '" + 
				date.get(Calendar.YEAR) + "-" + 
				(date.get(Calendar.MONTH)+1) + "-" + //Bugfix: set january as 1, december as 12
				date.get(Calendar.DAY_OF_MONTH) + " " +
				date.get(Calendar.HOUR_OF_DAY) + ":" +
				date.get(Calendar.MINUTE) + ":" +
				date.get(Calendar.SECOND) + "'";
		
		//Connect with db
		try {
			connect = dataSource.getConnection();
			stmt = connect.createStatement();
			rs = stmt.executeQuery(query);
			
			//Check if query result is empty
			if (rs.next()==false) {
				return false;
			}			
			
			connect.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}	
		return true;
	}

	//Check cities list, add some to DB if that's needed
	private void areAllCitiesInDBAndAddIfNotThenAdd()
	{
		this.data.setCityList(new CitiesList(this.dataSource));
		ArrayList<String> citiesNames = this.data.getCityList().getNames();
	/////// POPRAW ŹRÓDLO	
		for (String city : this.data.getCityNames()) {
			if(!citiesNames.contains(city)) {
				try {
					String query = "INSERT INTO `cities`(`city_name`) VALUES (?)";
					Connection connect = this.dataSource.getConnection();
					PreparedStatement statement = connect.prepareStatement(query);
					statement.setString(1, city);
					statement.execute();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				
			}
		}
	}

	//Transfers blood.... levels :) Add records to DB
	private void insertBloodLevels() {
		
		Connection connect=null;
		Statement stmt = null;
		ResultSet rs = null;
		
		String query = null;
	
		//Prepare table with bloodTypes
		ArrayList<BloodType> types = new ArrayList<BloodType>();
		types.add(BloodType.ZERO_RH_N);
		types.add(BloodType.ZERO_RH_P);
		types.add(BloodType.A_RH_N);
		types.add(BloodType.A_RH_P);
		types.add(BloodType.B_RH_N);
		types.add(BloodType.B_RH_P);
		types.add(BloodType.AB_RH_N);
		types.add(BloodType.AB_RH_P);
		
		try {
			connect=dataSource.getConnection();
			
			//Get actualisation ID
			query = "SELECT * FROM `actualization_date` ORDER BY `actualization_id` DESC LIMIT 1";
			stmt = connect.createStatement();
			rs=stmt.executeQuery(query);
			rs.next();
			int actualization_id = rs.getInt(1);
			
			for(TableRow row : this.data.getValuesRows()) {
				
				//Get type_id from blood_type table
				String bloodTyp = row.getBloodType().getBloodTypeName();
				query="SELECT * FROM blood_type WHERE type_name = '"+bloodTyp+"' LIMIT 1";
				stmt=connect.createStatement();
				rs=stmt.executeQuery(query);
				rs.next();
				int bloodTypId = rs.getInt(1);
				
				//Check if number of cities equals number of blood levels
				if(this.data.getCityNames().size()!=row.values.size())
				{throw new Exception ("Number of cities don't match number of blood levels!!!!!!");}
				
				for (int i=1;i<=row.values.size();i++) {
					query = "INSERT INTO `blood_levels`(`city_id`, `type_id`, `actualization_id`, `blood_level`) VALUES (?,?,?,?)";
					PreparedStatement statement = connect.prepareStatement(query);
					
					//GetCityNumber
					int cityId = this.data.getCityList().getId(i-1);
					
					statement.setInt(1, cityId);
					statement.setInt(2, bloodTypId);
					statement.setInt(3, actualization_id);
					statement.setInt(4, row.values.get(i-1));
					
					statement.execute();
				}
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		
		//INSERT INTO `blood_levels`( `city_id`, `type_id`, `actualization_id`) VALUES ([value-1],[value-2],[value-3])
		//INSERT INTO blood_levels  ( `city_id`, `type_id`, `actualization_id`) VALUES 
		
	}
}
